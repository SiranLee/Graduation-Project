function time = compute_wait(plaza)
time = sum(sum(plaza>0));