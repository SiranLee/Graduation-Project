function count = compute_output(plaza)
count = sum(plaza(end,:)>0);