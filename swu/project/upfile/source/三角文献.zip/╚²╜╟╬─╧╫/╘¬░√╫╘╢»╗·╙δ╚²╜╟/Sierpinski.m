% ��ʶ��ܵĴ�С
maxScale = 65;
z = zeros(maxScale,maxScale);
odds = 0;
evens = 0;
yangTri = zeros(maxScale,maxScale);
% ��ʼ��Ԫ��״̬
cells = z;
cells(1,ceil(maxScale/2)) = 1; 
yangTri(1,ceil(maxScale/2)) = 1; 
% ����ͼ����
imhandle = image(cat(3,cells,z,z));
% ����Ԫ�����µ���ʼ��
row = 2;
colum = 2;
while i <= maxScale 
  for i  = row : maxScale
      startIndex = ceil(maxScale/2)-i+1;
      endIndex = startIndex + 2*(i-1);
      step = 1;
      appTimes = zeros(1,i);
      subTrsaction = zeros(1,i);
      for j = colum : maxScale-1
          yangTri(i,j) = yangTri(i-1,j-1)+yangTri(i-1,j+1);
          cells(i,j) = mod((cells(i-1,j-1)+cells(i-1,j+1)),2);
      end
      set(imhandle,'cdata',cat(3,cells,z,z));
      drawnow;
      pause(0.1);
  end
end
