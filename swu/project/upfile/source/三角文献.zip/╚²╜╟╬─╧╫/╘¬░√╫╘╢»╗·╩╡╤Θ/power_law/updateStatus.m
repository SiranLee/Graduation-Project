function z = updateStatus(cells)
    cellsSize = size(cells,1);
    for i = 2:cellsSize
        binNums = '';
        for j = 1:i
            binNums = strcat(binNums,32,num2str(cells(i,j)));
        end
        decNum = bin2dec(binNums)+1;
        if(decNum>2^i-1)
            decNum = 0;
        end
        binNums = dec2bin(decNum,i);
        for k = 1:i
            cells(i,k) = str2num(binNums(i));
        end
    end
    z = cells;
end