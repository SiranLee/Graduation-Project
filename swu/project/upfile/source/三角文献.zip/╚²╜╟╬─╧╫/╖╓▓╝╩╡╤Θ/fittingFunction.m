function f = fittingFunction(X,xdata)
    f = X(1)*(xdata+X(2)).^X(3);
end
