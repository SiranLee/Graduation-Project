function coes = disFitting(bpaMatrix,bpaCounts)
    % x
    x = 0:0.1:0.9;
    coes = zeros(9,3);
    for i = 1:9
        subplot(3,3,i);
        hold on
        title(strcat('N=',num2str(i+1)));
        plot(x,bpaCounts(i,:),'ro-');
        [coe,renom]=lsqcurvefit(@fittingFunction,[1,1,-1],x,bpaCounts(i,:));
        coes(i,:) = coe;
        plot(x,fittingFunction(coe,x),'b*-');
        hold off
    end
end