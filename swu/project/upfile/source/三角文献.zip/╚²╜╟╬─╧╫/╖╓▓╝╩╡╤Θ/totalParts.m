function parts = total_parts(scale)
  parts = 0;
  for i = 0:scale
      parts = parts + nchoosek(scale,i)*(2^i-1);
  end
end