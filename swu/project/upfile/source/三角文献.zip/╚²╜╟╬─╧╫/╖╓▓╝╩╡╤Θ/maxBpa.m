% ��ʶ��ܵĴ�С
scale = 2:10;
gap = 10;
legends = '';
bpaMatrix = zeros(7,256);
bpaCounts = zeros(7,gap);
for i = 2:size(scale,2)+1
   bpas = zeros(2^scale(i-1),1);
   subsetSize = subsetSizes(scale(i-1))
   parts = totalParts(i);
   for j = 1:2^i
       bpaMatrix(i-1,j) = subsetSize(j)/parts;
       bpas(j) = bpaMatrix(i-1,j);
   end
   bpaCounts(i-1,:) = hist(bpas,gap);
end
%handle = histogram(bpas,'Normalization','pdf');
%title(strcat('N=',num2str(scale(i))));
coes = disFitting(bpaMatrix,bpaCounts);




