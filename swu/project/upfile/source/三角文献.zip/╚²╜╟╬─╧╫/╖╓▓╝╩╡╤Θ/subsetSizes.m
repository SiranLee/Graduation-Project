function counts = subsetSizes(scale)
    sizes = zeros(1,scale+1); 
    for i = 1:scale+1
        sizes(i) = sizes(i)+nchoosek(scale,i-1)
    end
    index = 1;
    counts = zeros(1,2^scale);
    for j = 1:size(sizes,2)
        for k = 1:sizes(j)
           counts(index) = 2^(j-1)-1;
           index = index + 1;
        end
    end
end